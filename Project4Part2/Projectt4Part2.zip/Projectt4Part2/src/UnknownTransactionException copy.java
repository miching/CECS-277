/**
 * A concrete class that reports an unknown transaction
 * @author Amir Hammoud
 * @author Katrina Orevillo
 * @author Michael Ching
 * Date: 10-21-2020
 */
public class UnknownTransactionException extends Exception
{
    public UnknownTransactionException() {}

    public UnknownTransactionException(String message) {
        super(message);
    }

    @Override
    /**
     * Overriden toString method.
     * @return The string representation of an UnknownTransactionException.
     */
    public String toString() {
        return super.toString();
    }
}