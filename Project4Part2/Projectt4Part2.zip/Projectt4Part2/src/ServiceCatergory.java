import java.io. * ;
import java.util. * ;

/**
 * A concrete class that provides methods to read sale entries from the user and print each sale to
 * a specific category of text files.
 * @author Amir Hammoud
 * @author Katrina Orevillo
 * @author Michael Ching
 * Date: 10-21-2020
 */

public class ServiceCatergory {
	
	
	/**
	 * Reads in the file and separates the different elements into individual Strings
	 * @param input Scanner
	 * @return A string containing name, service, amount and date
	 */
	private static String readSaleEntry(Scanner input) {
    	String name = null;
		String service = null;
		double amount = 0;
		String date = null;

		String inputLine = input.nextLine();
		Scanner lineScan = new Scanner(inputLine);
		lineScan.useDelimiter(";");

		while(lineScan.hasNext())
		{
			
			name = lineScan.next();
			service = lineScan.next();
			amount = lineScan.nextDouble();
			date = lineScan.next();
			
		}



		return (name + ";" + service + ";" + amount + ";" + date);
    }

	
	/**
	 * Reads the file and puts them into an arrayList
	 * @param filename The name of the file to be read
	 * @return An arraylist of strings containing the sales
	 * @throws FileNotFoundException
	 */
	private static ArrayList<String> readSalesFile(String filename)
			throws FileNotFoundException
	{

		ArrayList<String> sales = new ArrayList<String>();

		if (filename != null)
		{
			try (Scanner infile = new Scanner(new File(filename)))
			{
				while (infile.hasNext())
				{ 
					
					sales.add(readSaleEntry(infile));
					
				}
			}
		}
		
		return sales;
	
	}
	
	
	 /**
     * Writes the sales to a text file.
     * @param out
     * @param sale
     */
    private static void writeSale(PrintWriter out, String sale) {
    	
    	String [] tokens = sale.split(";");
    	
        out.print(tokens[0]);
        out.print(";");

        out.print(tokens[1]);
        out.print(";");

        out.print(tokens[2]);
        out.print(";");

        out.print(tokens[3]);
        out.println();
    }
    	
    /**
     * Separate each transition into its own file
     * @param args a text file containing transactions
     * @throws FileNotFoundException
     */
        public static void main(String[] args) throws FileNotFoundException
        {

    		String filename = args[0];
    		System.out.println(filename);
        	
            PrintWriter breakfast = new PrintWriter("breakfast.txt");
            PrintWriter lunch = new PrintWriter("lunch.txt");
            PrintWriter dinner = new PrintWriter("dinner.txt");
            PrintWriter lounging = new PrintWriter("lounging.txt");
            PrintWriter conference = new PrintWriter("conference.txt");
            
            ArrayList <String >sales = new ArrayList <String> ();
            
            sales = readSalesFile(filename);
            
          
               
                try {
                    
                	
                	for (String s : sales) 
        			{
        				
                		if(s.contains("Breakfast"))
                		{
                			
                			writeSale(breakfast, s);
                			
                		}
                		
                		else if(s.contains("Lunch"))
                		{
                			
                			writeSale(lunch, s);
                			
                		}
                		
                		else if(s.contains("Dinner"))
                		{
                			
                			writeSale(dinner, s);
                			
                		}
                		
                		else if(s.contains("Lounging"))
                		{
                			
                			writeSale(lounging, s);
                			
                		}
                		
                		else if(s.contains("Conference"))
                		{
                			
                			writeSale(conference, s);
                			
                		}
                		
        				
        			}
                   
                	breakfast.close();
                    lunch.close();
                    dinner.close();
                    lounging.close();
                    conference.close();
                   
                }

                catch (InputMismatchException e) {
                    System.out.println("\nPlease enter a valid whole number.\n");
                }

                catch(NoSuchElementException e) {
                    System.out.println("\nFile format not valid.\n");
                }
             
        }
}